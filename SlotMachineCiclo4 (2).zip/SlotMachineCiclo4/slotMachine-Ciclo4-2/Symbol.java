/**
 * Simbolo normal de una rueda: tiene un color, un tamaño y un
 * estado de visibilidad. Sus subclases cambian ese comportamiento.
 * 
 * @author: Joan Acosta y Maria Rojas
 * @version: 1.0
 */
public class Symbol{
    private String color;
    private int size;
    private boolean visible;

    /**
     * Crea un simbolo del color dado, visible y de tamano normal.
     * 
     * @param color El color CSS del simbolo.
     */
    public Symbol(String color){
        this.color = color;
        this.size = Wheel.diametroN;
        this.visible = true;
    }

    /**
     * @return El color CSS del simbolo.
     */
    public String getColor(){
        return color;
    }

    /**
     * @return El tamano actual del simbolo.
     */
    public int getSize(){
        return size;
    }

    /**
     * @return true si el simbolo esta visible, false de lo contrario.
     */
    public boolean isVisible(){
        return visible;
    }

    /**
     * Cambia el tamano del simbolo (para uso de las subclases).
     * 
     * @param size El nuevo tamano.
     */
    protected void setSize(int size){
        this.size = size;
    }

    /**
     * Cambia la visibilidad del simbolo (para uso de las subclases).
     * 
     * @param visible El nuevo estado de visibilidad.
     */
    protected void setVisible(boolean visible){
        this.visible = visible;
    }
        /**
     * Se llama cada vez que la rueda gira. Un simbolo normal no hace nada.
     */
    public void onSpin(){
    }

    /**
     * Crea una copia de este simbolo (mismo tipo y color, estado inicial).
     * 
     * @return Un simbolo nuevo del mismo tipo.
     */
    public Symbol copy(){
        return new Symbol(color);
    }
    /**
     * Se llama cada vez que este simbolo es seleccionado en la rueda.
     * Un simbolo normal no hace nada.
     */
    public void onSelected(){
    }
}