import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias del ciclo 4.
 * Autores: Joan Acosta Fajardo y Maria Rojas Ramirez.
 */
public class SlotMachineC4Test{

    /**
     * QUE DEBERIA HACER: addWheel con tipo "normal" debe agregar
     * la rueda y dejar ok() en true.
     */
    @Test
    public void shouldAddNormalWheelByType(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        assertTrue(sm.ok());
        assertEquals(1, sm.configuration().length);
    }

    /**
     * QUE DEBERIA HACER: addWheel con un tipo desconocido debe
     * fallar (ok() en false) y no agregar ninguna rueda.
     */
    @Test
    public void shouldNotAddWheelOfUnknownType(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("xyz", 1);
        assertFalse(sm.ok());
        assertEquals(0, sm.configuration().length);
    }
        /**
     * QUE DEBERIA HACER: una rueda rebel no se deja bloquear;
     * lock debe fallar (ok() en false).
     */
    @Test
    public void shouldNotLockRebelWheel(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("rebel", 1);
        sm.lock(1);
        assertFalse(sm.ok());
    }

    /**
     * QUE DEBERIA HACER: una rueda rebel no se deja intercambiar;
     * swap debe fallar (ok() en false).
     */
    @Test
    public void shouldNotSwapRebelWheel(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("rebel", 1);
        sm.addWheel("normal", 2);
        sm.swap(1, 2);
        assertFalse(sm.ok());
    }

    /**
     * QUE DEBERIA HACER: una rueda rebel no se deja eliminar;
     * delWheel debe fallar y la rueda debe seguir existiendo.
     */
    @Test
    public void shouldNotDeleteRebelWheel(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("rebel", 1);
        sm.delWheel(1);
        assertFalse(sm.ok());
        assertEquals(1, sm.configuration().length);
    }

    /**
     * QUE DEBERIA HACER: una rueda normal sigue pudiendo
     * bloquearse (no rompimos el comportamiento anterior).
     */
    @Test
    public void shouldStillLockNormalWheel(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        sm.lock(1);
        assertTrue(sm.ok());
    }
    /**
     * QUE DEBERIA HACER: al girar una rueda lefty que tiene otra a
     * su izquierda, debe quedar con el mismo color que esa rueda.
     */
    @Test
    public void shouldLeftyCopyLeftWheelWhenSpun(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        sm.addWheel("lefty", 2);
        sm.addSymbol(1, "red");
        sm.addSymbol(2, "blue");
        sm.addSymbol(3, "green");
        sm.placeSymbol(1, "blue");
        sm.spin(2);
        assertTrue(sm.ok());
        assertEquals("blue", sm.configuration()[1]);
    }

    /**
     * QUE DEBERIA HACER: con spin() de todas las ruedas, la lefty
     * debe copiar el nuevo color que tomo la rueda de su izquierda.
     */
    @Test
    public void shouldLeftyMatchLeftWheelAfterSpinAll(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        sm.addWheel("lefty", 2);
        sm.addSymbol(1, "red");
        sm.addSymbol(2, "blue");
        sm.addSymbol(3, "green");
        sm.spin();
        String[] config = sm.configuration();
        assertEquals(config[0], config[1]);
    }

    /**
     * QUE DEBERIA HACER: una lefty sin rueda a su izquierda
     * (posicion 1) debe poder girar sin fallar.
     */
    @Test
    public void shouldLeftyInFirstPositionSpinNormally(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("lefty", 1);
        sm.addSymbol(1, "red");
        sm.addSymbol(2, "blue");
        sm.spin(1);
        assertTrue(sm.ok());
    }
        /**
     * QUE DEBERIA HACER: tras el refactor, symbols() debe seguir
     * devolviendo los colores en el orden en que se agregaron.
     */
    @Test
    public void shouldKeepSymbolColorsInOrder(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        sm.addSymbol(1, "red");
        sm.addSymbol(2, "blue");
        String[] colores = sm.symbols();
        assertEquals(2, colores.length);
        assertEquals("red", colores[0]);
        assertEquals("blue", colores[1]);
    }
    /**
     * QUE DEBERIA HACER: un simbolo ephemeral decrece su tamano en
     * cada giro y nunca baja de 1 (un punto).
     */
    @Test
    public void shouldEphemeralSymbolShrinkUntilPoint(){
        EphemeralSymbol s = new EphemeralSymbol("red");
        s.onSpin();
        assertTrue(s.getSize() < Wheel.diametroN);
        for (int i = 0; i < 20; i = i + 1){
            s.onSpin();
        }
        assertEquals(1, s.getSize());
    }

    /**
     * QUE DEBERIA HACER: addSymbol con tipo "ephemeral" agrega el
     * simbolo y deja ok() en true.
     */
    @Test
    public void shouldAddEphemeralSymbolByType(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        sm.addSymbol("ephemeral", 1, "red");
        assertTrue(sm.ok());
        assertEquals(1, sm.symbols().length);
    }

    /**
     * QUE DEBERIA HACER: addSymbol con un tipo desconocido falla
     * y no agrega ningun simbolo.
     */
    @Test
    public void shouldNotAddSymbolOfUnknownType(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        sm.addSymbol("xyz", 1, "red");
        assertFalse(sm.ok());
        assertEquals(0, sm.symbols().length);
    }
        /**
     * QUE DEBERIA HACER: un simbolo shy alterna entre invisible y
     * visible cada vez que es seleccionado en la rueda.
     */
    @Test
    public void shouldShySymbolToggleVisibilityWhenSelected(){
        Wheel w = new Wheel();
        w.addSymbol(1, new ShySymbol("red"));
        assertTrue(w.isCurrentSymbolVisible());
        w.placeSymbol("red");
        assertFalse(w.isCurrentSymbolVisible());
        w.placeSymbol("red");
        assertTrue(w.isCurrentSymbolVisible());
    }

    /**
     * QUE DEBERIA HACER: un simbolo normal nunca cambia su
     * visibilidad al ser seleccionado.
     */
    @Test
    public void shouldNormalSymbolStayVisibleWhenSelected(){
        Wheel w = new Wheel();
        w.addSymbol(1, "red");
        w.placeSymbol("red");
        w.placeSymbol("red");
        assertTrue(w.isCurrentSymbolVisible());
    }

    /**
     * QUE DEBERIA HACER: addSymbol con tipo "shy" agrega el simbolo
     * y deja ok() en true.
     */
    @Test
    public void shouldAddShySymbolByType(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        sm.addSymbol("shy", 1, "red");
        assertTrue(sm.ok());
        assertEquals(1, sm.symbols().length);
    }
}