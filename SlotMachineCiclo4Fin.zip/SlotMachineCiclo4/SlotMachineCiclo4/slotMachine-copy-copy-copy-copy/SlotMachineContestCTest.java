import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

/**
 * Clase de pruebas unitarias para SlotMachineContest. 
 * Autores: Joan Acosta Fajardo y Maria Rojas Ramirez.
 */
public class SlotMachineContestCTest{

    /**
     * Construye una maquina de n ruedas con n colores conocidos
     * (sin azar), dejando cada rueda en el color indicado en
     * colores[i]. Util para tener control total del estado inicial
     * en las pruebas.
     */
    private SlotMachine construirMaquinaConocida(String[] colores){
        int n = colores.length;
        SlotMachine sm = new SlotMachine();
        for (int i = 0; i < n; i = i + 1){
            sm.addWheel(i + 1);
        }
        for (int i = 0; i < n; i = i + 1){
            sm.addSymbol(i + 1, colores[i]);
        }
        for (int i = 0; i < n; i = i + 1){
            sm.placeSymbol(i + 1, colores[i]);
        }
        return sm;
    }

    /**
     * QUE DEBERIA HACER: si la maquina YA esta en jackpot antes de
     * empezar, resolver no debe hacer ningun movimiento (la
     * secuencia de acciones debe venir vacia) y la maquina debe
     * seguir en jackpot.
     */
    @Test
    public void accordingAfRrShouldReturnNoActionsWhenAlreadyJackpot(){
        SlotMachine sm = construirMaquinaConocida(new String[]{"red", "red", "red"});

        int[][] acciones = SlotMachineContest.resolver(sm, 3);

        assertEquals(0, acciones.length);
        assertEquals(1, sm.distinctSymbols());
    }

    /**
     * QUE DEBERIA HACER: con una maquina de 3 ruedas en colores
     * totalmente distintos, resolver debe dejarla en jackpot
     * (distinctSymbols() == 1) usando una secuencia de acciones
     * valida (cada accion con rueda entre 1 y n).
     */
    @Test
    public void accordingAfRrShouldReachJackpotFromFullyDistinctWheels(){
        SlotMachine sm = construirMaquinaConocida(new String[]{"red", "blue", "green"});

        int[][] acciones = SlotMachineContest.resolver(sm, 3);

        assertEquals(1, sm.distinctSymbols());
        for (int i = 0; i < acciones.length; i = i + 1){
            assertEquals(2, acciones[i].length);
            assertTrue(acciones[i][0] >= 1 && acciones[i][0] <= 3);
        }
    }
}