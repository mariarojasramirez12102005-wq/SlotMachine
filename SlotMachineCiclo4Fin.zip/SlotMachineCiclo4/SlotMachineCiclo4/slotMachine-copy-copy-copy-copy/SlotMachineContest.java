import java.util.ArrayList;
import java.util.List;

/**
 * Resuelve y simula el problema de la maratón usando SlotMachine unicamente como
 * caja negra: SlotMachine(n), spin(wheel,steps) y distinctSymbols()
 * para resolver; makeVisible()/makeInvisible() para simular.
 *
 * @author: Joan Acosta Fajardo y Maria Rojas Ramirez
 * @version: 1.0
 */
public class SlotMachineContest{

    /**
     * Resuelve el problema de la maratón sobre una maquina de n
     * ruedas/simbolos inicializada al azar (invisible). Devuelve
     * la secuencia de acciones {i,j} (rueda, pasos) que llevan a
     * la maquina a jackpot.
     * 
     * @param n Cantidad de ruedas y simbolos iniciales de la maquina tragamonedas.
     * @return Una matriz cada fila representa una accion {rueda, pasos}.
     */
    public static int[][] solve(int n){
        SlotMachine sm = new SlotMachine(n);
        List<int[]> acciones = new ArrayList<>();

        for (int k = 2; k <= n && sm.distinctSymbols() > 1; k = k + 1){
            alinearRueda(sm, k, acciones, n);
        }

        int[][] resultado = new int[acciones.size()][2];
        for (int i = 0; i < acciones.size(); i = i + 1){
            resultado[i] = acciones.get(i);
        }
        return resultado;
    }

    /**
     * Simula en vivo (maquina visible) el mismo proceso de solve,
     * sobre una maquina de n ruedas/simbolos propia, inicializada
     * al azar.
     * 
     * @param n Cantidad de ruedas y simbolos de la maquina a simular en pantalla.
     */
    public static void simulate(int n){
        SlotMachine sm = new SlotMachine(n);
        sm.makeVisible();
        List<int[]> acciones = new ArrayList<>();

        for (int k = 2; k <= n && sm.distinctSymbols() > 1; k = k + 1){
            alinearRueda(sm, k, acciones, n);
        }
    }

    /** 
     * Alinea la rueda k con las ruedas anteriores, probando los posibles 
     * desplazamientos de la rueda hasta encontrar la posicion en la que 
     * muestra el mismo simbolo que las ruedas ya alineadas. 
     * 
     * La rueda se gira una posicion a la vez y, despues de cada giro, 
     * se verifica si las ruedas 1 hasta k muestran el mismo simbolo. 
     * Como cada rueda contiene los mismos simbolos en el mismo orden, 
     * despues de como maximo n giros se encuentra la posicion buscada. 
     * 
     * @param sm La maquina tragamonedas sobre la cual se realiza la operacion. 
     * @param k El numero de la rueda que se desea alinear, comenzando desde 2. 
     * @param acciones La lista donde se almacenan las acciones realizadas, 
     * indicando la rueda y el numero de pasos. 
     * @param n El numero total de simbolos que tiene cada rueda. 
     */
    private static void alinearRueda(SlotMachine sm, int k, List<int[]> acciones, int n){
        for (int i = 0; i < n; i = i + 1){
    
            String[] configuracion = sm.configuration();
    
            boolean iguales = true;
    
            for (int j = 1; j < k; j = j + 1){
                if (!configuracion[j].equals(configuracion[0])){
                    iguales = false;
                }
            }
    
            if (iguales && configuracion[k - 1].equals(configuracion[0])){
                return;
            }
            sm.spin(k, 1);
            acciones.add(new int[]{k, 1});
        }
    }
    
    /** 
     * Resuelve el problema de la maquina tragamonedas para una maquina 
     * con n ruedas. Comienza alineando la segunda rueda con la primera 
     * y continua de forma consecutiva hasta alinear todas las ruedas. 
     * 
     * Cada accion realizada se almacena como un par {rueda, pasos}, 
     * donde rueda indica la rueda que se gira y pasos indica la cantidad 
     * de posiciones que avanza. 
     * 
     * @param n El numero de ruedas de la maquina tragamonedas. 
     * @return Una matriz donde cada fila representa una accion realizada, 
     * con el formato {rueda, pasos}. 
     */
    public static int[][] resolver(SlotMachine sm, int n){
        List<int[]> acciones = new ArrayList<>();
        for (int k = 2; k <= n && sm.distinctSymbols() > 1; k = k + 1){
            alinearRueda(sm, k, acciones, n);
        }
        int[][] resultado = new int[acciones.size()][2];
        for (int i = 0; i < acciones.size(); i = i + 1){
            resultado[i] = acciones.get(i);
        }
        return resultado;
    }
}