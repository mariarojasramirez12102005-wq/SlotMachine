import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias del ciclo 4.
 * Autores: Joan Acosta Fajardo y Maria Rojas Ramirez.
 */
public class SlotMachineC4Test{

    /**
     * QUE DEBERIA HACER: addWheel con tipo "normal" debe agregar
     * la rueda y dejar ok() en true.
     */
    @Test
    public void shouldAddNormalWheelByType(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("normal", 1);
        assertTrue(sm.ok());
        assertEquals(1, sm.configuration().length);
    }

    /**
     * QUE DEBERIA HACER: addWheel con un tipo desconocido debe
     * fallar (ok() en false) y no agregar ninguna rueda.
     */
    @Test
    public void shouldNotAddWheelOfUnknownType(){
        SlotMachine sm = new SlotMachine();
        sm.addWheel("xyz", 1);
        assertFalse(sm.ok());
        assertEquals(0, sm.configuration().length);
    }
}