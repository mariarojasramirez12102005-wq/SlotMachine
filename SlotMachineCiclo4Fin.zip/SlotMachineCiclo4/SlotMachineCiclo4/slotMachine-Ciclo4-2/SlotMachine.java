import javax.swing.JOptionPane;
import java.util.Random;

/**
 * La maquina tragamonedas.
 * Guarda un grupo de ruedas y sabe si la ultima operacion
 * que se hizo funciono bien o no.
 * 
 * @author: Joan Acosta y Maria Rojas
 * @version: 1.0
 */
public class SlotMachine{

    private Wheel[] wheels;   
    private boolean ok;       
    private boolean visible;
    private Rectangle caja;
    private Random random;
    private static final String[] CSS_COLORS = {
        "red", "black", "blue", "yellow", "green", "magenta", "white"
    };
    private static final int margenX = 40;         // padding izquierda/derecha alrededor de las ruedas
    private static final int margenY = 50;         // padding arriba/abajo alrededor de las ruedas
    // Punto de anclaje de toda la maquina en el canvas (esquina superior
    // izquierda de la caja). El canvas ahora es de 600x300 (ver Canvas.java).
    private static final int origenX = 60;
    private static final int origenY = 60;
    // Ancho del Canvas (debe coincidir con el valor usado en Canvas.java,
    // Canvas("BlueJ Shapes Demo", 600, 300, ...)). Se usa para saber si
    // una rueda mas cabe antes de agregarla.
    private static final int anchoCanvas = 600;
    // Posicion por defecto del constructor de Rectangle (fija, no cambiar
    // salvo que cambie Rectangle.java).
    private static final int rectanguloDefectoX = 70;
    private static final int rectanguloDefectoY = 15;

    /**
     * Constructor: crea la maquina sin ruedas todavia.
     */
    public SlotMachine(){
        wheels = new Wheel[0];   
        ok = true;
        visible = false;
        random = new Random();
        caja = new Rectangle();
        inicializarCaja();
    }

    /**
     * Crea una maquina con n ruedas y n simbolos (colores CSS tomados
     * en orden de la lista estandar), cada rueda en una posicion
     * inicial aleatoria. Pensada para usarse como caja negra al
     * resolver o simular el problema de la maratón.
     * 
     * @param n El numero de ruedas y simbolos iniciales a crear.
     */
    public SlotMachine(int n){
        this();
        for (int i = 0; i < n; i = i + 1){
            addWheel(i + 1);
        }
        for (int i = 0; i < n; i = i + 1){
            addSymbol(i + 1, CSS_COLORS[i]);
        }
        for (int i = 0; i < n; i = i + 1){
            placeSymbol(i + 1, CSS_COLORS[random.nextInt(n)]);
        }
    }

    /**
     * Posiciona la caja de la maquina en las coordenadas de origen establecidas.
     */
     private void posicionarCaja(){
        int dx = origenX - rectanguloDefectoX;
        int dy = origenY - rectanguloDefectoY;
        caja.moveHorizontal(dx);
        caja.moveVertical(dy);
    }
 
    /**
     * Recalcula el ancho de la caja para que contenga exactamente
     * todas las ruedas actuales, con margen.
     * Se oculta si la maquina no tiene ruedas.
     */
    private void actualizarCaja(){
        if (wheels.length == 0){
            caja.makeInvisible();
            return;
        }
        int ancho = (wheels.length - 1) * Wheel.separacion + Wheel.diametroN
                    + 2 * margenX;
        int alto = Wheel.diametroN + 2 * margenY;
        caja.changeSize(alto, ancho);
        if (visible){
            caja.makeVisible();
        }
    }

    /**
     * Inicializa la caja visual posicionandola y actualizando su tamaño.
     */
    private void inicializarCaja(){
        posicionarCaja();
        actualizarCaja();
    }

    /**
     * Agrega una rueda nueva en la posicion indicada.
     * Si pos es menor a 1, se usa la posicion 1.
     * Si pos es mayor al numero de ruedas, se agrega al final.
     * 
     * @param pos La posicion en la que se agregara la nueva rueda (1-indexado).
     */
        /**
     * Agrega una rueda normal en la posicion indicada.
     * Equivale a addWheel("normal", pos).
     * 
     * @param pos La posicion en la que se agregara la nueva rueda (1-indexado).
     */
    public void addWheel(int pos){
        addWheel("normal", pos);
    }

    /**
     * Agrega una rueda del tipo indicado en la posicion indicada.
     * Si el tipo no existe, falla y no agrega nada.
     * Si pos es menor a 1, se usa la posicion 1.
     * Si pos es mayor al numero de ruedas, se agrega al final.
     * 
     * @param type El tipo de rueda a crear (por ahora solo "normal").
     * @param pos La posicion en la que se agregara la nueva rueda (1-indexado).
     */
    public void addWheel(String type, int pos){
        Wheel nueva = crearRueda(type);
        if (nueva == null){
            fail("Tipo de rueda desconocido: " + type);
            return;
        }
        int anchoResultante = wheels.length * Wheel.separacion + Wheel.diametroN + 2 * margenX;
        if (visible && origenX + anchoResultante > anchoCanvas){
            fail("No hay espacio en el canvas para otra rueda.");
            return;
        }
        if (pos < 1){
            pos = 1;
        }
        if (pos > wheels.length + 1){
            pos = wheels.length + 1;
        }
        Wheel[] newWheels = new Wheel[wheels.length + 1];
        int posReal = pos - 1;
        for (int i = 0; i < posReal; i = i + 1){
            newWheels[i] = wheels[i];
        }
        newWheels[posReal] = nueva;
        String[] simbolosBase = (wheels.length > 0) ? wheels[0].symbols() : new String[0];
        if (wheels.length > 0){
            newWheels[posReal].copySymbolsFrom(wheels[0]);
        }
        if (simbolosBase.length > 0){
            String colorInicial = simbolosBase[random.nextInt(simbolosBase.length)];
            newWheels[posReal].placeSymbol(colorInicial);
        }
        for (int i = posReal; i < wheels.length; i = i + 1){
            newWheels[i + 1] = wheels[i];
        }
        wheels = newWheels;
        ok = true;
        reposWheel();
        actualizarCaja();
        if (visible){
            wheels[posReal].makeVisible();
        }
        actualizarEganador();
    }

    /**
     * Fabrica de ruedas: crea una rueda segun su tipo.
     * 
     * @param type El nombre del tipo de rueda.
     * @return La rueda creada, o null si el tipo no existe.
     */
    private Wheel crearRueda(String type){
        if (type == null){
            return null;
        }
        if (type.toLowerCase().equals("normal")){
            return new Wheel();
        }
        if (type.toLowerCase().equals("rebel")){
            return new RebelWheel();
        }
        if (type.toLowerCase().equals("lefty")){
            return new LeftyWheel();
        }
        return null;
    }
    /**
     * Fabrica de simbolos: crea un simbolo segun su tipo.
     * 
     * @param type El nombre del tipo de simbolo.
     * @param color El color CSS del simbolo.
     * @return El simbolo creado, o null si el tipo no existe.
     */
    private Symbol crearSimbolo(String type, String color){
        if (type == null){
            return null;
        }
        String t = type.toLowerCase();
        if (t.equals("normal")){
            return new Symbol(color);
        }
        if (t.equals("ephemeral")){
            return new EphemeralSymbol(color);
        }
        if (t.equals("shy")){
            return new ShySymbol(color);
        }
        if (t.equals("golden")){
            return new GoldenSymbol(color);
        }
        return null;
    }
    /**
     * Elimina la rueda que esta en la posicion indicada.
     * Falla si la maquina no tiene ruedas.
     * 
     * @param pos La posicion de la rueda que se desea eliminar (1-indexado).
     */
    public void delWheel(int pos){
        if (wheels.length == 0){
            fail("no hay ruedas para eliminar");
            return;
        }
        if (pos < 1){
            pos = 1;
        }
        if (pos > wheels.length){
            pos = wheels.length;
        }
        int posReal = pos - 1;
        if (!wheels[posReal].canBeDeleted()){
            fail("La rueda " + pos + " es rebelde y no se deja eliminar.");
            return;
        }
        wheels[posReal].makeInvisible();
        for (int i = posReal; i < wheels.length - 1; i = i + 1){
            wheels[i] = wheels[i + 1];
        }
        Wheel[] newWheels = new Wheel[wheels.length - 1];
        for (int i = 0; i < newWheels.length; i = i + 1){
            newWheels[i] = wheels[i];
        }
        wheels = newWheels;
        ok = true;
        reposWheel();
        actualizarCaja();
        actualizarEganador();
    }

    /**
     * Agrega un simbolo normal del color dado en la posicion pos de
     * todas las ruedas. Equivale a addSymbol("normal", pos, color).
     * 
     * @param pos La posicion en la que se agregara el color dentro de la rueda.
     * @param color El color CSS que se agregara como simbolo.
     */
    public void addSymbol(int pos, String color){
        addSymbol("normal", pos, color);
    }

    /**
     * Agrega un simbolo del tipo dado en la posicion pos de TODAS
     * las ruedas. Falla si el tipo no existe, si el color no es un
     * color CSS valido, o si ese color ya existe en la maquina.
     * 
     * @param type El tipo de simbolo ("normal" o "ephemeral").
     * @param pos La posicion en la que se agregara el simbolo.
     * @param color El color CSS del simbolo.
     */
    public void addSymbol(String type, int pos, String color){
        if (!esColorCSSValido(color)){
            fail("'" + color + "' no es un color CSS valido");
            return;
        }
        if (wheels.length > 0 && wheels[0].havesymbol(color)){
            fail("El color '" + color + "' ya existe; los simbolos deben ser de colores diferentes.");
            return;
        }
        if (crearSimbolo(type, color) == null){
            fail("Tipo de simbolo desconocido: " + type);
            return;
        }
        for (int i = 0; i < wheels.length; i = i + 1){
            wheels[i].addSymbol(pos, crearSimbolo(type, color));
        }
        ok = true;
        actualizarEganador();
    }

    /**
     * Quita el color dado de todas las ruedas.
     * Falla si el color no existe en la maquina.
     * 
     * @param color El color CSS del simbolo a eliminar.
     */
    public void delSymbol(String color){
        if (wheels.length == 0 || !wheels[0].havesymbol(color)){
            fail("El color '" + color + "' no existe en la maquina.");
            return;
        }
        for (int i = 0; i < wheels.length; i = i + 1){
            wheels[i].delSymbol(color);
        }
        ok = true;
        actualizarEganador();
    }

    /**
     * Pone el color indicado como visible en la rueda indicada.
     * 
     * @param wheel La rueda especifica (1-indexado).
     * @param symbol El simbolo (color CSS) que se desea mostrar.
     */
    public void placeSymbol(int wheel, String symbol){
        if (wheel < 1 || wheel > wheels.length){
            fail("La rueda " + wheel + " no existe.");
            return;
        }
        boolean encontrado = wheels[wheel - 1].placeSymbol(symbol);
        if (!encontrado){
            fail("El color '" + symbol + "' no esta en la rueda " + wheel + ".");
            return;
        }
        ok = true;
        actualizarEganador();
    }

    /**
     * Gira la rueda indicada a una posicion aleatoria.
     * 
     * @param wheel La posicion de la rueda a girar (1-indexado).
     */
    public void spin(int wheel){
        if (wheel < 1 || wheel > wheels.length){
            fail("La rueda " + wheel + " no existe.");
            return;
        }
        if (wheels[wheel - 1].isLocked()){
            fail("La rueda " + wheel + " esta fijada y no puede girar.");
            return;
        }
        wheels[wheel - 1].spinWith(wheel > 1 ? wheels[wheel - 2] : null);
        ok = true;
        actualizarEganador();
    }

    /**
     * Deja la maquina en la configuracion indicada: setSymbols[i] es
     * el color que debe quedar visible en la rueda i+1. El arreglo
     * debe tener exactamente un color por rueda, y cada color debe
     * ser un color CSS valido (se agrega a la rueda si no lo tenia).
     * Falla si el tamano no coincide o algun color no es valido.
     * 
     * @param setSymbols Arreglo de colores CSS correspondientes a cada rueda.
     */
    public void spin(String[] setSymbols){
        if (setSymbols == null || setSymbols.length != wheels.length){
            fail("Se necesita exactamente un color por cada una de las " + wheels.length + " ruedas.");
            return;
        }
        for (int i = 0; i < setSymbols.length; i = i + 1){
            if (!esColorCSSValido(setSymbols[i])){
                fail("'" + setSymbols[i] + "' no es un color CSS valido.");
                return;
            }
        }
        for (int i = 0; i < wheels.length; i = i + 1){
            if (wheels[i].isLocked()){
                fail("La rueda " + (i + 1) + " esta fijada y no puede cambiar de configuracion.");
                return;
            }
        }
        for (int i = 0; i < wheels.length; i = i + 1){
            if (!wheels[i].havesymbol(setSymbols[i])){
                wheels[i].addSymbol(1, setSymbols[i]);
            }
            wheels[i].placeSymbol(setSymbols[i]);
        }
        ok = true;
        actualizarEganador();
    }

    /**
     * Gira TODAS las ruedas al azar. El resultado depende de los
     * simbolos que tenga cada rueda; puede o no ser jackpot.
     */
    public void spin(){
        if (wheels.length == 0){
            fail("No hay ruedas para girar.");
            return;
        }
        for (int i = 0; i < wheels.length; i = i + 1){
            if (!wheels[i].isLocked()){
                wheels[i].spinWith(i > 0 ? wheels[i - 1] : null);
            }
        }
        ok = true;
        actualizarEganador();
    }

    /**
     * Obtiene los colores base de las ruedas.
     * 
     * @return Arreglo con los colores de la primera rueda (todas tienen los mismos).
     */
    public String[] symbols(){
        
        if (wheels.length == 0){
            return new String[0];
        }
        
        return wheels[0].symbols();
    }

    /**
     * Cuenta los simbolos distintos que estan actualmente visibles.
     * 
     * @return El numero de colores DISTINTOS que se ven ahora mismo entre todas las ruedas.
     */
    public int distinctSymbols(){
        String[] todos = configuration();
        int contador = 0;
        for (int i = 0; i < todos.length; i = i + 1){
            boolean yaLoConte = false;
            for (int j = 0; j < i; j = j + 1){
                if (todos[j].equals(todos[i])){
                    yaLoConte = true;
                }
            }
            if (yaLoConte == false){
                contador = contador + 1;
            }
        }
        return contador;
    }

    /**
     * Obtiene el estado visible de la maquina en el momento actual.
     * 
     * @return Arreglo con el color visible de cada rueda, de izquierda a derecha.
     */
    public String[] configuration(){
        String[] visibles = new String[wheels.length];
        for (int i = 0; i < wheels.length; i = i + 1){
            visibles[i] = wheels[i].currentSymbol();
        }
        return visibles;
    }

    /**
     * Verifica si todas las ruedas de la maquina muestran el mismo simbolo.
     * 
     * @return true si hay al menos 2 ruedas y todas muestran el mismo color, false de lo contrario.
     */
    public boolean isJackpot(){
        if (wheels.length < 2){
            return false;
        }
        String[] config = configuration();
        for (int i = 1; i < config.length; i = i + 1){
            if (config[i] == null || !config[i].equals(config[0])){
                return false;
            }
        }
        return true;
    }

    /**
     * Muestra todas las ruedas en pantalla.
     */
    public void makeVisible(){
        visible = true;
        caja.makeVisible();
        for (int i = 0; i < wheels.length; i = i + 1){
            wheels[i].makeVisible();
        }
    }

    /**
     * Oculta todas las ruedas.
     */
    public void makeInvisible(){
        visible = false;
        for (int i = 0; i < wheels.length; i = i + 1){
            wheels[i].makeInvisible();
        }
        caja.makeInvisible();
    }

    /**
     * Termina el simulador ocultando los componentes.
     */
    public void exit(){
        makeInvisible();
        ok = true;
    }

    /**
     * Confirma si el ultimo comando o accion se realizo correctamente.
     * 
     * @return true si la ultima operacion se pudo realizar, false si fallo.
     */
    public boolean ok(){
        return ok;
    }

    /**
     * Registra un fallo en la operacion actual y muestra un mensaje si la maquina es visible.
     * 
     * @param mensaje El texto que describe el motivo del fallo.
     */
    private void fail(String mensaje){
        ok = false;
        if (visible){
            JOptionPane.showMessageDialog(null, mensaje, "Operacion no realizada",
                JOptionPane.WARNING_MESSAGE);
        }
    }
 
    /**
     * Revisa si la maquina esta en estado ganador y actualiza
     * la apariencia de las ruedas en consecuencia.
     */
    private void actualizarEganador(){
        boolean gano = isJackpot();
        for (int i = 0; i < wheels.length; i = i + 1){
            if (gano){
                wheels[i].highlightwinner();
            } else {
                wheels[i].normalstate();
            }
        }
    }
 
    /**
     * Verifica que un string corresponda a un color valido.
     * 
     * @param color Nombre de color a validar.
     * @return true si el color corresponde a un nombre CSS estandar, false de lo contrario.
     */
    private boolean esColorCSSValido(String color){
        if (color == null){
            return false;
        }
        String colorMin = color.toLowerCase();
        for (int i = 0; i < CSS_COLORS.length; i = i + 1){
            if (CSS_COLORS[i].equals(colorMin)){
                return true;
            }
        }
        return false;
    }

    /**
     * Reubica visualmente todas las ruedas en fila, en el
     * mismo orden en que estan guardadas en el arreglo.
     */
    private void reposWheel(){
        for (int i = 0; i < wheels.length; i = i + 1){
            wheels[i].moverA(i, origenX + margenX, origenY + margenY);
        }
    
    }
    
    /**
     * Intercambia las ruedas que estan en las posiciones wheel1 y wheel2
     * (posiciones fisicas en la fila, 1-indexadas). Falla si alguna
     * posicion no existe.
     * 
     * @param wheel1 Posicion de la primera rueda a intercambiar.
     * @param wheel2 Posicion de la segunda rueda a intercambiar.
     */
    public void swap(int wheel1, int wheel2){
        if (wheel1 < 1 || wheel1 > wheels.length || wheel2 < 1 || wheel2 > wheels.length){
            fail("Alguna de las ruedas indicadas no existe.");
            return;
        }
        int i1 = wheel1 - 1;
        int i2 = wheel2 - 1;
        if (!wheels[i1].canBeSwapped() || !wheels[i2].canBeSwapped()){
            fail("Alguna de las ruedas es rebelde y no se deja intercambiar.");
            return;
        }
        Wheel temp = wheels[i1];
        wheels[i1] = wheels[i2];
        wheels[i2] = temp;
        ok = true;
        reposWheel();
        actualizarEganador();
    }

    /**
     * Fija la rueda indicada: mientras este fijada, no gira cuando 
     * se llama spin() sobre todas las ruedas. Falla si la rueda no existe.
     * 
     * @param wheel Posicion de la rueda que se desea fijar (1-indexado).
     */
    public void lock(int wheel){
        if (wheel < 1 || wheel > wheels.length){
            fail("La rueda " + wheel + " no existe.");
            return;
        }
        if (!wheels[wheel - 1].canBeLocked()){
            fail("La rueda " + wheel + " es rebelde y no se deja bloquear.");
            return;
        }
        wheels[wheel - 1].lock();
        ok = true;
    }
    
    /**
     * Suelta la rueda indicada, para que vuelva a girar con spin().
     * Falla si la rueda no existe.
     * 
     * @param wheel Posicion de la rueda que se desea desbloquear (1-indexado).
     */
    public void unlock(int wheel){
        if (wheel < 1 || wheel > wheels.length){
            fail("La rueda " + wheel + " no existe.");
            return;
        }
        wheels[wheel - 1].unlock();
        ok = true;
    }
    
    /**
     * Rota la rueda indicada un numero de pasos (positivo = adelante,
     * negativo = atras), en vez de girarla al azar. Falla si la
     * rueda no existe.
     * 
     * @param wheel Posicion de la rueda a rotar (1-indexado).
     * @param steps Numero de pasos para rotar (positivo o negativo).
     */
    public void spin(int wheel, int steps){
        if (wheel < 1 || wheel > wheels.length){
            fail("La rueda " + wheel + " no existe.");
            return;
        }
        if (wheels[wheel - 1].isLocked()){
            fail("La rueda " + wheel + " esta fijada y no puede girar.");
            return;
        }
        wheels[wheel - 1].rotate(steps);
        ok = true;
        actualizarEganador();
    }
}