/**
 * Rueda lefty: si hay una rueda a su izquierda, al girar copia su estado.
 * Si no la hay, gira al azar como una rueda normal.
 * 
 * @author: Joan Acosta y Maria Rojas
 * @version: 1.0
 */
public class LeftyWheel extends Wheel{

    /**
     * Copia el color visible de la rueda de la izquierda. Si no hay
     * rueda a la izquierda, o ese color no existe en esta rueda,
     * gira al azar.
     * 
     * @param left La rueda a la izquierda de esta, o null si no tiene.
     */
    @Override
    public void spinWith(Wheel left){
        if (left == null || !placeSymbol(left.currentSymbol())){
            spin();
        }
    }
}