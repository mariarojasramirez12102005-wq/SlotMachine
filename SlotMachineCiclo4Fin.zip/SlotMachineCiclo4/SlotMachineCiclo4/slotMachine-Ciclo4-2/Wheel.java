import java.util.Random;

/**
 * Representa una rueda individual de la maquina tragamonedas.
 * Cada rueda mantiene su propia lista de simbolos (colores),
 * cual esta mostrando actualmente, y su representacion visual.
 * 
 * @author: Joan Acosta y Maria Rojas 
 * @version: 1.0
 */
public class Wheel{
    private Symbol[] symbols;
    private int currentPosition;
    private boolean isVisible;
    private Circle circle;
    private Random random;
    private int posX;
    private int posY;
    private boolean resaltado;
    public static final int diametroN = 40;
    public  static final int diametroG = 55;
    public static final int separacion = 80;
    private boolean locked;
    
    /**
     * Crea una rueda vacia, sin simbolos, invisible.
     */
    public Wheel(){
        symbols = new Symbol[0];
        currentPosition = 0;
        isVisible = false;
        circle = new Circle();
        random= new Random();
        posX = 20;
        posY = 15;
        resaltado = false;
        locked = false;
    }

        /**
     * Agrega un simbolo normal del color dado en la posicion indicada.
     * 
     * @param pos posicion donde insertar (1-indexado)
     * @param color color CSS del simbolo a insertar
     */
    public void addSymbol(int pos, String color){
        addSymbol(pos, new Symbol(color));
    }

    /**
     * Agrega el simbolo dado en la posicion indicada.
     * Si pos es menor a 1, se usa la posicion 1. Si es mayor
     * al numero de simbolos, se agrega al final.
     * 
     * @param pos posicion donde insertar (1-indexado)
     * @param symbol simbolo a insertar
     */
    public void addSymbol(int pos, Symbol symbol){
        if (pos < 1){
            pos = 1;
        }
        if (pos > symbols.length + 1){
            pos = symbols.length + 1;
        }
        Symbol[] newSymbols = new Symbol[symbols.length + 1];
        int posReal = pos - 1;
        for (int i = 0; i < posReal; i = i + 1){
            newSymbols[i] = symbols[i];
        }
        newSymbols[posReal] = symbol;
        for (int i = posReal; i < symbols.length; i = i + 1){
            newSymbols[i + 1] = symbols[i];
        }
        symbols = newSymbols;
        actualizarCirculo();
    }

        public void delSymbol(String color){
        int posABorrar = -1;
        for (int i = 0; i < symbols.length; i = i + 1){
            if (symbols[i].getColor().equals(color)){
                posABorrar = i;
                break;
            }
        }
        if (posABorrar == -1){
            return;
        }
        for (int i = posABorrar; i < symbols.length - 1; i = i + 1){
            symbols[i] = symbols[i + 1];
        }
        Symbol[] newSymbols = new Symbol[symbols.length - 1];
        for (int i = 0; i < newSymbols.length; i = i + 1){
            newSymbols[i] = symbols[i];
        }
        symbols = newSymbols;
        if (currentPosition >= symbols.length){
            currentPosition = 0;
        }
        actualizarCirculo();
    }

    /**
     * Coloca directamente el color dado como el simbolo visible,
     * si existe en la lista de simbolos de esta rueda.
     * 
     * @param color color CSS a mostrar
     * @return true si el color existe en la rueda y se pudo colocar, false de lo contrario
     */
    public boolean placeSymbol(String color){
        for (int i = 0; i < symbols.length; i = i + 1){
            if (symbols[i].getColor().equals(color)){
                seleccionar(i);
                return true;
            }
        }
        return false;
    }

    /**
     * Gira la rueda a una posicion aleatoria entre sus simbolos.
     */
    public void spin(){
        if (symbols.length == 0){
            return;
        }
        notificarGiro();
        seleccionar(random.nextInt(symbols.length));
        actualizarCirculo();
    }

    /**
     * Obtiene la cantidad de simbolos que hay en la rueda.
     * 
     * @return el numero de simbolos que tiene esta rueda
     */
    public int numSymbols(){
        return symbols.length;
    }
    
    /**
     * Verifica si la rueda contiene el simbolo (color) dado.
     * 
     * @param color El color CSS a buscar en la rueda.
     * @return true si la rueda contiene el simbolo, false de lo contrario.
     */
    public boolean havesymbol(String color){
        for (int i = 0; i<symbols.length;i=i+1){
            if (symbols[i].getColor().equals(color)){
                return true;
            }
        }
        return false;
    }

    /**
     * Retorna el simbolo actual que se esta mostrando.
     * 
     * @return el color visible actualmente, o null si la rueda
     *         no tiene simbolos
     */
    public String currentSymbol(){
        if (symbols.length == 0){
            return null;
        }
        return symbols[currentPosition].getColor();
    }

    /**
     * Genera una copia de la lista de simbolos.
     * 
     * @return copia del arreglo de colores de esta rueda, en
     *         orden, desde la posicion 1
     */
    public String[] symbols(){
        String[] copia = new String[symbols.length];
        for (int i = 0; i < symbols.length; i = i + 1){
            copia[i] = symbols[i].getColor();
        }
        return copia;
    }

    /**
     * Hace visible la representacion grafica de esta rueda.
     */
        public void makeVisible(){
        isVisible = true;
        actualizarVisibilidad();
    }
    /**
     * Hace invisible la representacion grafica de esta rueda.
     */
    public void makeInvisible(){
        isVisible = false;
        circle.makeInvisible();
    }

     /**
     * Resalta visualmente esta rueda porque la maquina gano
     * (la agranda). No hace nada si ya estaba resaltada.
     */
    public void highlightwinner(){
        if (!resaltado){
            circle.changeSize(diametroG);
            resaltado = true;
        }
    }

    /**
     * Vuelve al tamaño normal de la rueda (estado no ganador).
     * No hace nada si ya estaba en estado normal.
     */
    public void normalstate(){
        if (symbols.length == 0){
            circle.changeSize(diametroN);
        } else {
            circle.changeSize(symbols[currentPosition].getSize());
        }
        resaltado = false;
    }

    /**
     * Actualiza el color de la figura visual para que coincida
     * con el simbolo actualmente visible.
     */
    private void actualizarCirculo(){
        String color = currentSymbol();
        if (color != null){
            circle.changeColor(color);
            if (!resaltado){
                circle.changeSize(symbols[currentPosition].getSize());
            }
        }
        actualizarVisibilidad();
    }

    /**
     * Mueve el circulo de esta rueda hasta el puesto horizontal
     * indicado (0 = primera rueda, 1 = segunda, etc).
     * Cada puesto separa el circulo 80 pixeles del anterior.
     * 
     * @param indice Posicion en la fila de ruedas.
     * @param baseX Coordenada base en el eje X de la maquina.
     * @param baseY Coordenada base en el eje Y de la maquina.
     */
    public void moverA(int indice, int baseX, int baseY){
        int destinoX = baseX + indice * separacion;
        posicionarA(destinoX, baseY);
    }
    
    /**
     * Posiciona el circulo en unas coordenadas especificas.
     * 
     * @param x Destino en el eje X.
     * @param y Destino en el eje Y.
     */
    private void posicionarA(int x, int y){
        int dx = x - posX;
        int dy = y - posY;
        if (dx != 0){
            circle.moveHorizontal(dx);
        }
        if (dy != 0){
            circle.moveVertical(dy);
        }
        posX = x;
        posY = y;
    }
    
    /**
     * Fija esta rueda: mientras este fijada, no gira al llamar
     * spin() sobre todas las ruedas de la maquina.
     */
    public void lock(){
        locked = true;
    }
    
    /**
     * Suelta esta rueda: vuelve a girar normalmente con spin().
     */
    public void unlock(){
        locked = false;
    }
    
    /**
     * Verifica si esta rueda esta bloqueada o no.
     * 
     * @return true si esta rueda esta actualmente fijada, false si puede girar
     */
    public boolean isLocked(){
        return locked;
    }
        /**
     * Indica si esta rueda se deja bloquear.
     * 
     * @return true si puede bloquearse, false de lo contrario.
     */
    public boolean canBeLocked(){
        return true;
    }

    /**
     * Indica si esta rueda se deja intercambiar de posicion.
     * 
     * @return true si puede intercambiarse, false de lo contrario.
     */
    public boolean canBeSwapped(){
        return true;
    }

    /**
     * Indica si esta rueda se deja eliminar.
     * 
     * @return true si puede eliminarse, false de lo contrario.
     */
    public boolean canBeDeleted(){
        return true;
    }
    /**
     * Rota la rueda un numero de pasos hacia adelante (steps positivo) 
     * o hacia atras (steps negativo), avanzando de a un simbolo a la
     * vez, con una pausa de 1 segundo entre cada paso, para que el
     * giro se vea paso a paso en pantalla.
     * No hace nada si la rueda no tiene simbolos.
     * 
     * @param steps Numero de pasos para rotar.
     */
    public void rotate(int steps){
        if (symbols.length == 0){
            return;
        }
        notificarGiro();
        int direccion = (steps >= 0) ? 1 : -1;
        int totalPasos = Math.abs(steps);
        for (int i = 0; i < totalPasos; i = i + 1){
            int nueva = currentPosition + direccion;
            if (nueva >= symbols.length){
                nueva = 0;
            }
            if (nueva < 0){
                nueva = symbols.length - 1;
            }
            seleccionar(nueva);
            if (isVisible){
                try{
                    Thread.sleep(500);
                } catch (InterruptedException e){
                }
            }
        }
    }
    
    public void spinWith(Wheel left){
        spin();
    }
        /**
     * Avisa a todos los simbolos de la rueda que ocurrio un giro.
     */
    private void notificarGiro(){
        for (int i = 0; i < symbols.length; i = i + 1){
            symbols[i].onSpin();
        }
    }

    /**
     * Copia los simbolos (con su tipo) de otra rueda, en el mismo orden.
     * 
     * @param other La rueda de la que se copian los simbolos.
     */
    public void copySymbolsFrom(Wheel other){
        for (int i = 0; i < other.symbols.length; i = i + 1){
            addSymbol(i + 1, other.symbols[i].copy());
        }
    }
        /**
     * Deja el simbolo de la posicion dada como el actual y le avisa
     * que fue seleccionado.
     * 
     * @param pos Indice (0-indexado) del simbolo a seleccionar.
     */
    private void seleccionar(int pos){
        currentPosition = pos;
        symbols[pos].onSelected();
        actualizarCirculo();
    }

    /**
     * Indica si el simbolo que muestra la rueda esta visible.
     * 
     * @return true si esta visible (o si la rueda no tiene simbolos).
     */
    public boolean isCurrentSymbolVisible(){
        return symbols.length == 0 || symbols[currentPosition].isVisible();
    }

    /**
     * Muestra el circulo solo si la rueda es visible y su simbolo
     * actual tambien lo es.
     */
    private void actualizarVisibilidad(){
        if (isVisible && isCurrentSymbolVisible()){
            circle.makeVisible();
        } else {
            circle.makeInvisible();
        }
    }
}