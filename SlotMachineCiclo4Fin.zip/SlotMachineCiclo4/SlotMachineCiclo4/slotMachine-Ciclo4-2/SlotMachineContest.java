import java.util.ArrayList;
import java.util.List;

/**
 * Resuelve y simula el problema de la maraton usando SlotMachine unicamente como
 * caja negra: SlotMachine(n), spin(wheel,steps) y distinctSymbols()
 * para resolver; makeVisible()/makeInvisible() para simular.
 *
 * @author: Joan Acosta Fajardo y Maria Rojas Ramirez
 * @version: 1.0
 */
public class SlotMachineContest{

    /**
     * Resuelve el problema de la maraton creando una maquina invisible.
     *
     * @param n numero de ruedas y simbolos de la maquina
     * @return arreglo de acciones necesarias para obtener el jackpot
     */
    public static int[][] solve(int n){
        SlotMachine sm = new SlotMachine(n);
        return resolver(sm, n);
    }

    /**
     * Simula la solucion del problema mostrando visualmente la maquina.
     *
     * @param n numero de ruedas y simbolos de la maquina
     */
    public static void simulate(int n){
        SlotMachine sm = new SlotMachine(n);
        sm.makeVisible();
        resolver(sm, n);
    }

    /**
     * Resuelve el problema utilizando la maquina como caja negra.
     *
     * Primero hace que todas las ruedas muestren simbolos diferentes.
     * Despues descubre el orden relativo de las ruedas y finalmente
     * las alinea para obtener el jackpot.
     *
     * @param sm maquina tragamonedas utilizada como caja negra
     * @param n numero de ruedas y simbolos
     * @return lista de acciones convertida en un arreglo
     */
    static int[][] resolver(SlotMachine sm, int n){
        List<int[]> acciones = new ArrayList<>();

        if (sm.distinctSymbols() == 1){
            return new int[0][2];
        }

        for (int rueda = 1; rueda <= n; rueda = rueda + 1){
            hacerDistintos(sm, rueda, n, acciones);
        }

        int[] siguiente = new int[n];

        for (int i = 0; i < n; i = i + 1){
            siguiente[i] = -1;
        }

        for (int i = 0; i < n; i = i + 1){
            for (int j = i + 1; j < n; j = j + 1){

                int resultado = compararRuedas(
                    sm,
                    i + 1,
                    j + 1,
                    n,
                    acciones
                );

                if (resultado == 1){
                    siguiente[i] = j;
                }
                else if (resultado == -1){
                    siguiente[j] = i;
                }
            }
        }

        int[] posicion = new int[n];

        for (int i = 0; i < n; i = i + 1){
            posicion[i] = -1;
        }

        int actual = 0;

        for (int paso = 0; paso < n; paso = paso + 1){
            posicion[actual] = paso;
            actual = siguiente[actual];
        }

        for (int rueda = 1; rueda < n; rueda = rueda + 1){
            girar(
                sm,
                rueda + 1,
                -posicion[rueda],
                acciones
            );
        }

        int[][] resultado = new int[acciones.size()][2];

        for (int i = 0; i < acciones.size(); i = i + 1){
            resultado[i] = acciones.get(i);
        }

        return resultado;
    }

    /**
     * Busca una posicion para la rueda en la que el numero de
     * simbolos distintos sea maximo.
     *
     * Como existen n simbolos y n ruedas, siempre es posible
     * encontrar una posicion que permita tener todos los simbolos
     * diferentes.
     *
     * @param sm maquina tragamonedas utilizada como caja negra
     * @param rueda numero de la rueda que se desea acomodar
     * @param n numero de posiciones de la rueda
     * @param acciones lista donde se almacenan los movimientos
     */
    private static void hacerDistintos(
        SlotMachine sm,
        int rueda,
        int n,
        List<int[]> acciones
    ){
        int mejor = sm.distinctSymbols();
        int mejorPaso = 0;
        if (mejor == n){
            return;
        }

        for (int paso = 1; paso <= n; paso = paso + 1){

            girar(sm, rueda, 1, acciones);

            int actual = sm.distinctSymbols();

            if (actual > mejor){
                mejor = actual;
                mejorPaso = paso;
            }

            if (mejor == n){
                return;
            }
        }
        if (mejorPaso > 0){
            girar(sm, rueda, mejorPaso, acciones);
        }
    }

    /**
     * Compara dos ruedas para descubrir su posicion relativa.
     *
     * Si al girar la primera una posicion hacia adelante y la
     * segunda una posicion hacia atras siguen apareciendo los
     * n simbolos diferentes, entonces la segunda rueda esta
     * una posicion adelante de la primera.
     *
     * Si ocurre al contrario, la primera esta una posicion
     * adelante de la segunda.
     *
     * @param sm maquina tragamonedas utilizada como caja negra
     * @param rueda1 primera rueda
     * @param rueda2 segunda rueda
     * @param n numero de ruedas y simbolos
     * @param acciones lista donde se almacenan los movimientos
     * @return 1 si rueda2 esta adelante de rueda1,
     *         -1 si rueda1 esta adelante de rueda2,
     *         0 si no son consecutivas
     */
    private static int compararRuedas(
        SlotMachine sm,
        int rueda1,
        int rueda2,
        int n,
        List<int[]> acciones
    ){
        girar(sm, rueda1, 1, acciones);
        girar(sm, rueda2, -1, acciones);
        boolean primeraDireccion = sm.distinctSymbols() == n;
        girar(sm, rueda1, -1, acciones);
        girar(sm, rueda2, 1, acciones);
        if (primeraDireccion){
            return 1;
        }
        girar(sm, rueda1, -1, acciones);
        girar(sm, rueda2, 1, acciones);
        boolean segundaDireccion = sm.distinctSymbols() == n;
        girar(sm, rueda1, 1, acciones);
        girar(sm, rueda2, -1, acciones);
        if (segundaDireccion){
            return -1;
        }
        return 0;
    }

    /**
     * Gira una rueda y registra la accion realizada.
     *
     * No realiza ninguna accion si el numero de pasos es cero.
     *
     * @param sm maquina tragamonedas utilizada como caja negra
     * @param rueda numero de la rueda que se desea girar
     * @param pasos numero de posiciones que debe avanzar
     * @param acciones lista donde se almacena el movimiento
     */
    private static void girar(
        SlotMachine sm,
        int rueda,
        int pasos,
        List<int[]> acciones
    ){
        if (pasos == 0){
            return;
        }

        sm.spin(rueda, pasos);
        acciones.add(new int[]{rueda, pasos});
    }
}