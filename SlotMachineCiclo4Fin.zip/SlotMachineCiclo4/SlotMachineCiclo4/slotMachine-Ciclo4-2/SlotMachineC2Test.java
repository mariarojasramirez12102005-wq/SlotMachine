import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de unidad de SlotMachine para el ciclo 2.
 * Organizadas un metodo a la vez: para cada metodo se prueba
 * "que deberia hacer" y "que NO deberia hacer".
 * Todas las pruebas corren en modo invisible.
 *
 * @author Joan Acosta y Maria Rojas
 * @version 1.0
 */
public class SlotMachineC2Test {

    private SlotMachine machine;

    /**
     * Crea una maquina nueva antes de cada prueba, para que
     * ninguna prueba dependa del estado dejado por otra.
     */
    @BeforeEach
    public void setUp(){
        machine = new SlotMachine();
    }
    /**
     * Verifica que agregar una rueda funcione correctamente
     * cuando hay espacio disponible en el canvas.
     */
    @Test
    public void addWheelShouldAddAWheelSuccessfully(){
        machine.addWheel(1);
        assertTrue(machine.ok());
    }

    /**
     * Verifica que la maquina falle al intentar agregar una rueda
     * cuando ya no cabe mas en el ancho disponible del canvas.
     */
    @Test
    public void addWheelShouldFailWhenThereIsNoSpaceInCanvas(){
        boolean fallo = false;
        for (int i = 0; i < 20 && !fallo; i = i + 1){
            machine.addWheel(i + 1);
            if (!machine.ok()){
                fallo = true;
            }
        }
        assertTrue(fallo, "Deberia fallar al no caber mas ruedas en el canvas");
    }
    /**
     * Verifica que se pueda eliminar una rueda existente y que
     * el numero de ruedas disminuya correctamente.
     */
    @Test
    public void delWheelShouldRemoveAnExistingWheel(){
        machine.addWheel(1);
        machine.delWheel(1);
        assertTrue(machine.ok());
        assertEquals(0, machine.configuration().length);
    }

    /**
     * Verifica que la maquina falle al intentar eliminar una rueda
     * cuando no tiene ninguna rueda creada.
     */
    @Test
    public void delWheelShouldFailWhenThereAreNoWheels(){
        machine.delWheel(1);
        assertFalse(machine.ok());
    }
    /**
     * Verifica que se pueda agregar un color CSS valido a todas
     * las ruedas de la maquina.
     */
    @Test
    public void addSymbolShouldAddAValidColorToAllWheels(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        assertTrue(machine.ok());
        assertTrue(machine.symbols().length >= 1);
    }

    /**
     * Verifica que la maquina falle al intentar agregar un color
     * que no corresponde a un nombre CSS valido.
     */
    @Test
    public void addSymbolShouldFailWithAnInvalidCssColor(){
        machine.addWheel(1);
        machine.addSymbol(1, "colorInventado");
        assertFalse(machine.ok());
    }
    /**
     * Verifica que se pueda quitar un color existente de todas
     * las ruedas de la maquina.
     */
    @Test
    public void delSymbolShouldRemoveAnExistingColor(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.delSymbol("red");
        assertTrue(machine.ok());
        assertFalse(contiene(machine.symbols(), "red"));
    }

    /**
     * Verifica que la maquina falle al intentar quitar un color
     * que no existe en ninguna rueda.
     */
    @Test
    public void delSymbolShouldFailWhenColorDoesNotExist(){
        machine.addWheel(1);
        machine.delSymbol("red");
        assertFalse(machine.ok());
    }
    /**
     * Verifica que se pueda establecer el color visible de una
     * rueda cuando ese color existe entre sus simbolos.
     */
    @Test
    public void placeSymbolShouldSetTheVisibleSymbolOfAWheel(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.placeSymbol(1, "blue");
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }

    /**
     * Verifica que la maquina falle al intentar colocar un color
     * que no pertenece a los simbolos de la rueda indicada.
     */
    @Test
    public void placeSymbolShouldFailWhenColorIsNotInTheWheel(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.placeSymbol(1, "blue");
        assertFalse(machine.ok());
    }
    /**
     * Verifica que se pueda girar una rueda individual existente.
     */
    @Test
    public void spinSingleWheelShouldSucceedWhenWheelExists(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.spin(1);
        assertTrue(machine.ok());
    }

    /**
     * Verifica que la maquina falle al intentar girar una rueda
     * que no existe.
     */
    @Test
    public void spinSingleWheelShouldFailWhenWheelDoesNotExist(){
        machine.spin(1);
        assertFalse(machine.ok());
    }
    /**
     * Verifica que dejar la maquina en una configuracion dada
     * establezca exactamente el color indicado en cada rueda.
     */
    @Test
    public void spinWithConfigurationShouldSetExactColorsPerWheel(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.spin(new String[]{"red", "blue"});
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "blue"}, machine.configuration());
    }

    /**
     * Verifica que la maquina falle cuando el arreglo de colores
     * no tiene exactamente un color por cada rueda.
     */
    @Test
    public void spinWithConfigurationShouldFailWhenArraySizeDoesNotMatch(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.spin(new String[]{"red"});
        assertFalse(machine.ok());
    }
    /**
     * Verifica que se puedan girar todas las ruedas al azar
     * cuando la maquina tiene al menos una rueda.
     */
    @Test
    public void spinAllShouldSucceedWhenThereAreWheels(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.spin();
        assertTrue(machine.ok());
    }

    /**
     * Verifica que la maquina falle al intentar girar todas las
     * ruedas cuando no tiene ninguna.
     */
    @Test
    public void spinAllShouldFailWhenThereAreNoWheels(){
        machine.spin();
        assertFalse(machine.ok());
    }
    /**
     * Verifica que se devuelvan todos los colores agregados
     * a la maquina.
     */
    @Test
    public void symbolsShouldReturnAllColorsAddedToTheMachine(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        assertEquals(2, machine.symbols().length);
    }

    /**
     * Verifica que se devuelva un arreglo vacio cuando la maquina
     * no tiene ruedas ni simbolos.
     */
    @Test
    public void symbolsShouldReturnEmptyArrayWhenThereAreNoWheels(){
        assertEquals(0, machine.symbols().length);
    }
    /**
     * Verifica que se cuenten correctamente los colores distintos
     * que existen actualmente en la maquina.
     */
    @Test
    public void distinctSymbolsShouldCountUniqueColorsOnly(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        assertEquals(3, machine.distinctSymbols());
    }

    /**
     * Verifica que no se cuenten colores que nunca fueron
     * agregados a la maquina.
     */
    @Test
    public void distinctSymbolsShouldNotCountColorsThatWereNeverAdded(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        assertNotEquals(2, machine.distinctSymbols());
    }
    /**
     * Verifica que se devuelva un color visible por cada rueda
     * existente en la maquina.
     */
    @Test
    public void configurationShouldReturnOneVisibleColorPerWheel(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.spin(new String[]{"red", "blue"});
        assertEquals(2, machine.configuration().length);
    }

    /**
     * Verifica que la configuracion no incluya ruedas que ya
     * fueron eliminadas de la maquina.
     */
    @Test
    public void configurationShouldNotIncludeWheelsThatWereDeleted(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.delWheel(1);
        assertEquals(1, machine.configuration().length);
    }
    /**
     * Verifica que se declare jackpot cuando todas las ruedas
     * muestran el mismo color.
     */
    @Test
    public void isJackpotShouldBeTrueWhenAllWheelsShowTheSameColor(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.spin(new String[]{"red", "red"});
        assertTrue(machine.isJackpot());
    }

    /**
     * Verifica que no se declare jackpot cuando la maquina tiene
     * menos de dos ruedas.
     */
    @Test
    public void isJackpotShouldBeFalseWithFewerThanTwoWheels(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        assertFalse(machine.isJackpot());
    }
    /**
     * Verifica que intercambiar dos ruedas tambien intercambie
     * lo que cada una muestra en su configuracion.
     */
    @Test
    public void swapShouldExchangeTheConfigurationOfTwoWheels(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.spin(new String[]{"red", "blue"});
        machine.swap(1, 2);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "red"}, machine.configuration());
    }

    /**
     * Verifica que la maquina falle al intentar intercambiar una
     * rueda que no existe.
     */
    @Test
    public void swapShouldFailWhenAPositionDoesNotExist(){
        machine.addWheel(1);
        machine.swap(1, 2);
        assertFalse(machine.ok());
    }
    /**
     * Verifica que se pueda fijar una rueda que existe en
     * la maquina.
     */
    @Test
    public void lockShouldSucceedWhenWheelExists(){
        machine.addWheel(1);
        machine.lock(1);
        assertTrue(machine.ok());
    }

    /**
     * Verifica que la maquina falle al intentar fijar una rueda
     * que no existe.
     */
    @Test
    public void lockShouldFailWhenWheelDoesNotExist(){
        machine.lock(1);
        assertFalse(machine.ok());
    }
    /**
     * Verifica que una rueda previamente fijada pueda volver
     * a girar despues de soltarla.
     */
    @Test
    public void unlockShouldAllowAPreviouslyLockedWheelToBeSpun(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.lock(1);
        machine.unlock(1);
        machine.spin(1);
        assertTrue(machine.ok());
    }

    /**
     * Verifica que la maquina falle al intentar soltar una rueda
     * que no existe.
     */
    @Test
    public void unlockShouldFailWhenWheelDoesNotExist(){
        machine.unlock(1);
        assertFalse(machine.ok());
    }
    /**
     * Verifica que rotar una rueda un numero de pasos la mueva
     * exactamente esa cantidad de posiciones hacia adelante.
     */
    @Test
    public void spinWithStepsShouldMoveExactlyThatManyPositionsForward(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        machine.placeSymbol(1, "red");
        machine.spin(1, 2);
        assertTrue(machine.ok());
        assertEquals("green", machine.configuration()[0]);
    }

    /**
     * Verifica que la maquina falle al intentar rotar por pasos
     * una rueda que esta fijada.
     */
    @Test
    public void spinWithStepsShouldFailWhenWheelIsLocked(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.lock(1);
        machine.spin(1, 1);
        assertFalse(machine.ok());
    }
    /**
     * Verifica que terminar el simulador deje la maquina en
     * estado correcto.
     */
    @Test
    public void exitShouldLeaveTheMachineOk(){
        machine.addWheel(1);
        machine.exit();
        assertTrue(machine.ok());
    }
    /**
     * Busca un valor dentro de un arreglo de cadenas.
     *
     * @param arreglo arreglo de cadenas donde buscar
     * @param valor valor a buscar dentro del arreglo
     * @return true si el valor se encuentra en el arreglo
     */
    private boolean contiene(String[] arreglo, String valor){
        for (int i = 0; i < arreglo.length; i = i + 1){
            if (arreglo[i].equals(valor)){
                return true;
            }
        }
        return false;
    }
}