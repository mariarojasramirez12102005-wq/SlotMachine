/**
 * Rueda rebelde: no se deja bloquear, ni intercambiar, ni eliminar.
 * 
 * @author: Joan Acosta y Maria Rojas
 * @version: 1.0
 */
public class RebelWheel extends Wheel{

    /**
     * Una rueda rebelde nunca se deja bloquear.
     * 
     * @return siempre false.
     */
    @Override
    public boolean canBeLocked(){
        return false;
    }

    /**
     * Una rueda rebelde nunca se deja intercambiar.
     * 
     * @return siempre false.
     */
    @Override
    public boolean canBeSwapped(){
        return false;
    }

    /**
     * Una rueda rebelde nunca se deja eliminar.
     * 
     * @return siempre false.
     */
    @Override
    public boolean canBeDeleted(){
        return false;
    }
}