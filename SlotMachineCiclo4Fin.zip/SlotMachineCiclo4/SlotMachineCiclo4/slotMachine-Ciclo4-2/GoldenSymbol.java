/**
 * Simbolo dorado: cada vez que es seleccionado en la rueda, crece
 * un poco (hasta un tope maximo), como si acumulara suerte. Se
 * distingue visualmente de un simbolo normal porque, tras varias
 * apariciones, se ve notablemente mas grande.
 *
 * @author: Joan Acosta Fajardo y Maria Rojas Ramirez
 * @version: 1.0
 */
public class GoldenSymbol extends Symbol{

    private static final int incremento = 5;
    private static final int tamanoMaximo = Wheel.diametroG + 20;

    public GoldenSymbol(String color){
        super(color);
    }

    /**
     * Crece un poco cada vez que este simbolo queda seleccionado
     * en la rueda, sin pasar del tamano maximo.
     */
    @Override
    public void onSelected(){
        int nuevoTamano = getSize() + incremento;
        if (nuevoTamano > tamanoMaximo){
            nuevoTamano = tamanoMaximo;
        }
        setSize(nuevoTamano);
    }

    /**
     * Copia este simbolo conservando su tipo dorado (no uno normal).
     */
    @Override
    public Symbol copy(){
        return new GoldenSymbol(color);
    }
}