/**
 * Simbolo timido: cada vez que es seleccionado en la rueda,
 * alterna su estado entre visible e invisible.
 * 
 * @author: Joan Acosta y Maria Rojas
 * @version: 1.0
 */
public class ShySymbol extends Symbol{

    /**
     * Crea un simbolo timido del color dado (empieza visible).
     * 
     * @param color El color CSS del simbolo.
     */
    public ShySymbol(String color){
        super(color);
    }

    /**
     * Alterna la visibilidad cada vez que es seleccionado.
     */
    @Override
    public void onSelected(){
        setVisible(!isVisible());
    }

    /**
     * @return Un simbolo timido nuevo del mismo color.
     */
    @Override
    public Symbol copy(){
        return new ShySymbol(getColor());
    }
}