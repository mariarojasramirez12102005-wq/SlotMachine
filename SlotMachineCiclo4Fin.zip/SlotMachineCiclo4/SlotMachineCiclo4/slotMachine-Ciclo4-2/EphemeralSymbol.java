/**
 * Simbolo efimero: en cada giro de la rueda decrece su tamano
 * hasta quedar como un punto.
 * 
 * @author: Joan Acosta y Maria Rojas
 * @version: 1.0
 */
public class EphemeralSymbol extends Symbol{
    private static final int paso = 5;

    /**
     * Crea un simbolo efimero del color dado.
     * 
     * @param color El color CSS del simbolo.
     */
    public EphemeralSymbol(String color){
        super(color);
    }

    /**
     * Reduce el tamano en cada giro, sin bajar de 1 (un punto).
     */
    @Override
    public void onSpin(){
        int nuevo = getSize() - paso;
        if (nuevo < 1){
            nuevo = 1;
        }
        setSize(nuevo);
    }

    /**
     * @return Un simbolo efimero nuevo del mismo color.
     */
    @Override
    public Symbol copy(){
        return new EphemeralSymbol(getColor());
    }
}