import java.util.ArrayList;
import java.util.List;

/**
 * Resuelve y simula el problema de la maratón usando SlotMachine unicamente como
 * caja negra: SlotMachine(n), spin(wheel,steps) y distinctSymbols()
 * para resolver; makeVisible()/makeInvisible() para simular.
 *
 * @author: Joan Acosta Fajardo y Maria Rojas Ramirez
 * @version: 1.0
 */
public class SlotMachineContest{

    /**
     * Resuelve el problema de la maratón sobre una maquina de n
     * ruedas/simbolos inicializada al azar (invisible). Devuelve
     * la secuencia de acciones {i,j} (rueda, pasos) que llevan a
     * la maquina a jackpot.
     * 
     * @param n Cantidad de ruedas y simbolos iniciales de la maquina tragamonedas.
     * @return Una matriz cada fila representa una accion {rueda, pasos}.
     */
    public static int[][] solve(int n){
        SlotMachine sm = new SlotMachine(n);
        List<int[]> acciones = new ArrayList<>();

        for (int k = 2; k <= n && sm.distinctSymbols() > 1; k = k + 1){
            alinearRueda(sm, k, acciones, n);
        }

        int[][] resultado = new int[acciones.size()][2];
        for (int i = 0; i < acciones.size(); i = i + 1){
            resultado[i] = acciones.get(i);
        }
        return resultado;
    }

    /**
     * Simula en vivo (maquina visible) el mismo proceso de solve,
     * sobre una maquina de n ruedas/simbolos propia, inicializada
     * al azar.
     * 
     * @param n Cantidad de ruedas y simbolos de la maquina a simular en pantalla.
     */
    public static void simulate(int n){
        SlotMachine sm = new SlotMachine(n);
        sm.makeVisible();
        List<int[]> acciones = new ArrayList<>();

        for (int k = 2; k <= n && sm.distinctSymbols() > 1; k = k + 1){
            alinearRueda(sm, k, acciones, n);
        }
    }

    /**
     * Alinea la rueda k con el grupo ya confirmado (ruedas 1..k-1),
     * barriendola de a un paso y verificando cada bajada de conteo
     * contra el grupo completo antes de darla por buena.
     * 
     * @param sm       La instancia de la SlotMachine sobre la cual se esta operando.
     * @param k        El indice de la rueda actual que se busca alinear.
     * @param acciones La lista donde se registran las acciones {rueda, pasos} que se van realizando.
     * @param n        El numero total de ruedas que tiene la maquina.
     */
    private static void alinearRueda(SlotMachine sm, int k, List<int[]> acciones, int n){
        int base = sm.distinctSymbols();
        for (int paso = 0; paso < n; paso = paso + 1){
            sm.spin(k, 1);
            acciones.add(new int[]{k, 1});
            if (sm.distinctSymbols() < base){
                if (verificar(sm, k, acciones)){
                    return;
                }
            }
        }
    }

    /**
     * Mueve todo el grupo confirmado [1..k-1] un paso y lo regresa,
     * para revelar si la rueda k realmente estaba unida a ese grupo
     * (el conteo sube) o si la bajada fue una coincidencia con otra
     * rueda aun no procesada (el conteo no cambia).
     * 
     * @param sm       La instancia de la SlotMachine sobre la cual se esta operando.
     * @param k        El indice de la rueda que se esta verificando.
     * @param acciones La lista donde se registran las acciones temporales de la verificacion.
     * @return true si la rueda k esta verdaderamente alineada con el grupo confirmado, false si fue coincidencia.
     */
    private static boolean verificar(SlotMachine sm, int k, List<int[]> acciones){
        int antes = sm.distinctSymbols();
        for (int m = 1; m < k; m = m + 1){
            sm.spin(m, 1);
            acciones.add(new int[]{m, 1});
        }
        int despues = sm.distinctSymbols();
        for (int m = 1; m < k; m = m + 1){
            sm.spin(m, -1);
            acciones.add(new int[]{m, -1});
        }
        return despues > antes;
    }
}